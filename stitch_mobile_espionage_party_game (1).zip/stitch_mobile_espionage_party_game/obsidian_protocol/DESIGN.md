---
name: Obsidian Protocol
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#3a393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1c1b1c'
  surface-container: '#201f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c4c5d9'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#313031'
  outline: '#8e90a2'
  outline-variant: '#434656'
  surface-tint: '#b8c3ff'
  primary: '#b8c3ff'
  on-primary: '#002388'
  primary-container: '#2e5bff'
  on-primary-container: '#efefff'
  inverse-primary: '#124af0'
  secondary: '#ffb4aa'
  on-secondary: '#690003'
  secondary-container: '#c5020b'
  on-secondary-container: '#ffd2cc'
  tertiary: '#ffb59b'
  on-tertiary: '#5b1a00'
  tertiary-container: '#c24100'
  on-tertiary-container: '#ffece6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c3ff'
  on-primary-fixed: '#001356'
  on-primary-fixed-variant: '#0035be'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930005'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#812800'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  display-lg:
    fontFamily: Archivo Narrow
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Archivo Narrow
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: 0.05em
  headline-sm:
    fontFamily: Archivo Narrow
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.05em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  code-data:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  container-margin: 20px
  gutter: 12px
---

## Brand & Style
The design system embodies the tension between traditional noir espionage and modern digital panopticon surveillance. It targets players seeking an immersive, high-stakes social deduction experience. 

The aesthetic is **Digital Brutalism mixed with Tactical Minimalism**. It utilizes heavy borders, high-contrast intersections, and monospaced data readouts to simulate a classified operative's terminal. Visuals should evoke the feeling of viewing "forbidden" data—glitch effects, redacted bars, and scanline overlays are used to create texture without sacrificing legibility. The interface behaves like a secure dossier: rigid, authoritative, and cold.

## Colors
The palette is rooted in absolute shadows to facilitate a "stealth" environment. 

- **Deep Shadows & Stealth Grays:** Form the structural foundation. Use `#050505` for main backgrounds to ensure OLED blacks and `#3A3A3E` for secondary structural elements like borders and dividers.
- **Service Blue:** Used for "Safe" states, government-affiliated UI, and trusted intel. It represents the establishment and authority.
- **VIRUS Red:** Reserved for "Danger" states, Triple Agent alerts, countdowns, and system glitches. It should be used sparingly to maintain its high-impact psychological effect.
- **Accents:** Use a low-opacity white (10-15%) for scanline textures and "redacted" blocks.

## Typography
The typography system creates a hierarchy between "Public Information" (Sans-Serif) and "Internal System Data" (Monospace).

- **Headlines:** Use **Archivo Narrow** in all-caps for a condensed, urgent, and authoritative "Top Secret" dossier feel. 
- **Data & Metadata:** All technical readouts, timers, and player counts must use **JetBrains Mono**. This reinforces the high-tech surveillance theme.
- **Body Text:** Use **Inter** for game rules and long-form narrative text to ensure maximum readability during fast-paced party play.
- **Redaction:** Use the "label-caps" style on top of solid color blocks to represent "Classified" status.

## Layout & Spacing
The layout follows a **Rigid Tactical Grid**. Elements should feel like they are snapped into a surveillance monitor.

- **Grid:** Use a 12-column grid for desktop/tablet and a 4-column grid for mobile.
- **Visual Density:** Information density should be high but organized. Use heavy 2px strokes for "containers" rather than background fills to create a wireframe/blueprint aesthetic.
- **Responsive Behavior:** On mobile, margins tighten to 16px to maximize the "terminal" feel. Components should be full-width, stacked vertically like a scroll of decrypted data.

## Elevation & Depth
This design system eschews soft shadows in favor of **Tonal Layering and Tactical Overlays**.

- **Shadows:** Do not use diffused ambient shadows. Instead, use "Hard Multipliers"—1px or 2px solid black offsets to give elements a "stamped" or physical dossier look.
- **Glassmorphism:** Use sparingly for "HUD" overlays. A very subtle backdrop blur (4px) with a 10% white tint can be used for pop-up alerts to simulate a screen-on-screen effect.
- **The "Folder" Stack:** Depth is shown by physical overlap. A card appearing over another should have a crisp 1px "Service Blue" or "Stealth Gray" border to separate it from the background, simulating a folder being placed on a desk.
- **Textures:** Apply a global "scanline" SVG overlay (low-opacity horizontal lines) across the entire UI to unify the digital surveillance theme.

## Shapes
The shape language is **Sharp and Aggressive**. 

- **Corners:** 0px radius across all components. This emphasizes the brutalist, institutional nature of "The Service."
- **Angular Cuts:** For primary buttons or active tabs, use a 45-degree "clipped corner" (dog-eared) effect on the top-right to mimic military-spec hardware or clipped paper dossiers.
- **Dividers:** Use dashed or dotted lines for secondary divisions to suggest "tear-off" sections or digital transmissions.

## Components
- **Buttons:** 
  - *Primary:* Solid "Service Blue" with "Neutral Black" text. No rounding.
  - *Danger/Virus:* Solid "VIRUS Red" with a subtle "glitch" animation on hover.
  - *Ghost:* 2px Stealth Gray border, Monospace text.
- **Dossier Cards:** Use a `#121214` surface. The header of the card should be a solid bar of color with the title in a monospaced "label-caps" font.
- **Inputs:** Underlined only (1px stroke), simulating a form to be filled out. When focused, the stroke turns "Service Blue" with a flashing block cursor.
- **Redaction Blocks:** UI elements that hide "secret" roles should appear as solid `#3A3A3E` blocks. On tap/hover, they "dissolve" using a pixelate transition to reveal the identity.
- **Status Chips:** Small rectangular tags with monospaced text (e.g., [STATUS: COMPROMISED]). Use brackets to enclose the text.
- **The "Intel Feed":** A scrolling list of game events using JetBrains Mono, prefixed with a timestamp (e.g., `12:04:22 >> PLAYER_01 SCANNED`).